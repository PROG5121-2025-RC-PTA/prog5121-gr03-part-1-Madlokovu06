package com.mycompany.programmingasessment1a;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;

// MAIN CLASS
public class ProgrammingAsessment1A {
    public static void main(String[] args) {
        // User registration and login
        String username = JOptionPane.showInputDialog("Please enter username:");
        String password = JOptionPane.showInputDialog("Please enter password:");
        String cellPhoneNumber = JOptionPane.showInputDialog("Please enter SA cell phone number:");

        Login login = new Login(username, password, cellPhoneNumber);

        // Registration check
        String regMsg = login.registerUser();
        JOptionPane.showMessageDialog(null, regMsg);

        if (!regMsg.equals("User has been registered successfully.")) {
            return;  // Stop if registration failed
        }

        boolean loginSuccess = login.loginUser();
        JOptionPane.showMessageDialog(null, "Login status: " + (loginSuccess ? "Successful" : "Failed"));
        JOptionPane.showMessageDialog(null, "Message: " + login.returnLoginStatus());

        if (loginSuccess) {
            // Proceed with messaging functionality if login is successful
            String recipient = JOptionPane.showInputDialog("Enter recipient cell phone number (e.g. +27831234567):");
            String messageText = JOptionPane.showInputDialog("Enter your message:");

            Message msg = new Message(recipient, messageText);

            if (!msg.checkMessageID()) {
                JOptionPane.showMessageDialog(null, "Invalid Message ID: exceeds 10 digits");
                return;
            }

            if (!msg.checkRecipientCell()) {
                JOptionPane.showMessageDialog(null, "Invalid recipient phone number. Must start with +27 and be 12 characters long.");
                return;
            }

            msg.storeMessage();  // Store message to file
            JOptionPane.showMessageDialog(null, msg.sentMessage());

            // Show all messages
            JOptionPane.showMessageDialog(null, Message.printMessages());
        }
    }
}

// LOGIN CLASS
class Login {
    private final String username;
    private final String password;
    private final String cellPhoneNumber;
    private String loginStatus;

    public Login(String username, String password, String cellPhoneNumber) {
        this.username = username;
        this.password = password;
        this.cellPhoneNumber = cellPhoneNumber;
        this.loginStatus = "";
    }

    public boolean checkUserName() {
        return username != null && username.contains("_") && username.length() <= 8;
    }

    public boolean checkPasswordComplexity() {
        if (password == null || password.length() < 8) {
            return false;
        }

        Pattern pattern = Pattern.compile("^(?=.*[A-Z])(?=.*\\d)(?=.*[!@#$%^&*()_+\\-={}:\";'<>?,./]).{8,}$");
        Matcher matcher = pattern.matcher(password);
        return matcher.matches();
    }

    public boolean checkCellPhoneNumber() {
        return cellPhoneNumber != null && cellPhoneNumber.matches("^\\+27\\d{9}$"); // e.g. +27831234567
    }

    public boolean loginUser() {
        if (checkUserName() && checkPasswordComplexity() && checkCellPhoneNumber()) {
            loginStatus = "Login successful";
            return true;
        } else {
            loginStatus = "Login failed: invalid credentials";
            return false;
        }
    }

    public String returnLoginStatus() {
        return loginStatus;
    }

    public String registerUser() {
        if (!checkUserName()) {
            return "Username is incorrectly formatted. Please ensure it contains an underscore and is no more than 8 characters long.";
        }
        if (!checkPasswordComplexity()) {
            return "Password does not meet the complexity requirements.";
        }
        if (!checkCellPhoneNumber()) {
            return "Cell phone number is not valid. It should start with +27 and have 9 digits after.";
        }
        return "User has been registered successfully.";
    }
}

// MESSAGE CLASS
class Message {
    private static int totalMessages = 0;
    private static final String FILE_PATH = "messages.json";
    private static final ArrayList<Message> messageList = new ArrayList<>();

    private final long messageID;
    private final int messageNumber;
    private final String recipient;
    private final String messageText;
    private final String messageHash;

    public Message(String recipient, String messageText) {
        this.messageID = generateMessageID();
        this.messageNumber = ++totalMessages;
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageHash = createMessageHash();
    }

    public boolean checkMessageID() {
        return String.valueOf(this.messageID).length() <= 10;
    }

    public boolean checkRecipientCell() {
        return recipient != null && recipient.matches("^\\+27\\d{9}$");
    }

    public String createMessageHash() {
        String[] words = messageText.trim().split("\\s+");
        String first = words.length > 0 ? words[0] : "MSG";
        String last = words.length > 1 ? words[words.length - 1] : first;
        return String.format("%02d:%d:%s%s",
                messageID % 100,
                messageNumber,
                first.toUpperCase(),
                last.toUpperCase());
    }

    public String sentMessage() {
        return "Message sent";
    }

    public static String printMessages() {
        StringBuilder builder = new StringBuilder();
        for (Message msg : messageList) {
            builder.append("MessageID: ").append(msg.messageID).append("\n");
            builder.append("MessageHash: ").append(msg.messageHash).append("\n");
            builder.append("Recipient: ").append(msg.recipient).append("\n");
            builder.append("Message: ").append(msg.messageText).append("\n\n");
        }
        return builder.toString();
    }

    public static int returnTotalMessages() {
        return totalMessages;
    }

    public void storeMessage() {
        // Simulate a JSON object since org.json is not imported
        String jsonEntry = String.format(
                "{\"MessageID\":%d,\"MessageNumber\":%d,\"Recipient\":\"%s\",\"Message\":\"%s\",\"MessageHash\":\"%s\"}",
                this.messageID, this.messageNumber, this.recipient, this.messageText, this.messageHash);

        try (FileWriter file = new FileWriter(FILE_PATH, true)) {
            file.write(jsonEntry + "\n");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving message to file: " + e.getMessage());
        }

        messageList.add(this);
    }

    private long generateMessageID() {
        Random random = new Random();
        return 1000000000L + (long) (random.nextDouble() * 8999999999L);
    }
}
